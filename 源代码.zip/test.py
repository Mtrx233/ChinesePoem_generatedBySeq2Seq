import random
import torch
from torch import nn as nn
import numpy as np

str = "abscd"
print(str[2:4])