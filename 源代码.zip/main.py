if __name__ == '__main__':
    seq = []
    seq.append("<START>")